@echo off
setlocal
color b
:: Configuration
set GITHUB_USER=hardharryn
set GITHUB_TOKEN=TOKEN
set ORG_NAME=hardharryn
set REPO_NAME=LoyaltyApp
set BRANCH=develop-feature
set TARGET_DIR=%USERPROFILE%\Documents\LoyaltyApp

echo Setting Directory %TARGET_DIR%\%REPO_NAME%
:: Full repository path 
set REPO_PATH=%TARGET_DIR%\%REPO_NAME%

if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"

echo ========================================
echo Repository: %REPO_NAME%
echo Branch: %BRANCH%
echo ========================================
echo "%REPO_PATH%\.git"
if exist "%REPO_PATH%\.git" (
echo Repository already exists.
echo Pulling latest changes...

cd %REPO_PATH%
git remote set-url origin https://%GITHUB_USER%:%GITHUB_TOKEN%@github.com/%ORG_NAME%/%REPO_NAME%.git
echo "Set Global URL https://%GITHUB_USER%:TOKEN@github.com/%ORG_NAME%/%REPO_NAME%.git
git pull origin %BRANCH%
) else (
echo Repository does not exist.
echo Cloning repository...

cd /d "%TARGET_DIR%"

git clone --branch %BRANCH% --single-branch https://%GITHUB_USER%:%GITHUB_TOKEN%@github.com/%ORG_NAME%/%REPO_NAME%.git
)

if %ERRORLEVEL% EQU 0 (
echo.
color a
echo [SUCCESS]
pause
exit /b 0
) else (
echo.
color c
echo [FAILED]
pause
exit /b 1
)