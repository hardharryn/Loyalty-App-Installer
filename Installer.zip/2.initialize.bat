@echo off
cd /d "%USERPROFILE%\Documents\LoyaltyApp\LoyaltyApp" || exit /b 1
npm i

