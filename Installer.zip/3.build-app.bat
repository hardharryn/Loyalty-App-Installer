set NODE_TLS_REJECT_UNAUTHORIZED=0
cd /d "%USERPROFILE%\Documents\LoyaltyApp\LoyaltyApp" || exit /b 1
npm run build:win
explorer "%USERPROFILE%\Documents\LoyaltyApp\LoyaltyApp\dist"